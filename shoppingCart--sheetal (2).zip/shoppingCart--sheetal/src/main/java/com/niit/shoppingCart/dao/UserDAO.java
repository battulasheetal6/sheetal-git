package com.niit.shoppingCart.dao;

import com.niit.shoppingCart.model.User;

public interface UserDAO 
{
public void addUser(User user);
}
